# 👕 FX1 Digital Wardrobe – Surreal Badge Generator

Surreal NFT-inspired badge system built in **Node.js** with **Canvas**, showcasing fashion identity as part of the metaverse experience.  

Each badge evolves based on a **drip score streak** → unlocking higher tiers like **Cyber Hoodies**, **Pixelated Jackets**, **Glowing Shoes**, and more.

---

## 🚀 Features
- **Farcaster FID-linked badges**
- **Tiered fashion levels**
- **Royal Blue, Gold, Navy Blue, White surreal gradient**
- **Caching system for speed**
- **Fallback rendering**

---

## 📂 Planned Levels
1. Cyber Hoodie  
2. Glowing Hat  
3. Pixelated Jacket  
4. Pixelated Clothing  
5. Cyberpunk Clothing  
6. Crown  
7. Glowing Shoes  
8. Glowing Mask  
9. Digital Shirt  
