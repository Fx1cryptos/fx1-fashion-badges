const express = require("express");
const { createCanvas, loadImage, registerFont } = require("canvas");
const NodeCache = require("node-cache");
const path = require("path");

const cache = new NodeCache({ stdTTL: 3600 });
const router = express.Router();

// Register font
registerFont(path.join(__dirname, "../assets/fonts/Orbitron-Bold.ttf"), {
  family: "Orbitron"
});

// Fashion levels
const fashionLevels = [
  "Cyber Hoodie",
  "Glowing Hat",
  "Pixelated Jacket",
  "Pixelated Clothing",
  "Cyberpunk Clothing",
  "Crown",
  "Glowing Shoes",
  "Glowing Mask",
  "Digital Shirt"
];

router.get("/:fid/:streak", async (req, res) => {
  const { fid, streak } = req.params;
  const cacheKey = `${fid}-${streak}`;

  if (cache.has(cacheKey)) {
    return res.type("png").send(cache.get(cacheKey));
  }

  const canvas = createCanvas(600, 600);
  const ctx = canvas.getContext("2d");

  // Background gradient in Royal Blue, Gold, Navy Blue, White
  const gradient = ctx.createLinearGradient(0, 0, 600, 600);
  gradient.addColorStop(0, "#4169E1"); // Royal Blue
  gradient.addColorStop(0.33, "#FFD700"); // Gold
  gradient.addColorStop(0.66, "#000080"); // Navy Blue
  gradient.addColorStop(1, "#FFFFFF"); // White
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 600, 600);

  // Pick fashion layer
  const index = Math.min(parseInt(streak), fashionLevels.length - 1);
  const item = fashionLevels[index];

  const imagePath = path.join(__dirname, `../assets/base/${item.toLowerCase().replace(/ /g, "-")}.png`);
  try {
    const img = await loadImage(imagePath);
    ctx.drawImage(img, 50, 100, 500, 400);
  } catch {
    ctx.fillStyle = "white";
    ctx.fillText("⚠ Missing Asset", 200, 300);
  }

  // Text styles
  ctx.fillStyle = "#FFD700"; // Gold
  ctx.font = "30px Orbitron";
  ctx.fillText(`FID: ${fid}`, 180, 60);

  ctx.fillStyle = "#4169E1"; // Royal Blue
  ctx.font = "26px Orbitron";
  ctx.fillText(`Streak: ${streak}`, 200, 90);

  ctx.fillStyle = "#FFFFFF"; // White
  ctx.font = "bold 32px Orbitron";
  ctx.fillText(item, 150, 550);

  const buffer = canvas.toBuffer("image/png");
  cache.set(cacheKey, buffer);

  res.type("png").send(buffer);
});

module.exports = router;